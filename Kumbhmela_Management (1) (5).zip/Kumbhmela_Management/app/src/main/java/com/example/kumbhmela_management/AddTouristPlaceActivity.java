package com.example.kumbhmela_management;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddTouristPlaceActivity extends AppCompatActivity {

    private TextInputEditText etPlaceName, etLocation, etCategory,
            etEntryFee, etVisitingHours, etContact, etDescription;

    private MaterialButton btnSubmit;
    private ProgressDialog progressDialog;
    private DatabaseReference touristRef;
    String providerId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_tourist_place);

        initViews();
        SharedPreferences sp = getSharedPreferences("USER_SESSION", MODE_PRIVATE);
         providerId = sp.getString("USER_ID", null);

        if (providerId == null) {
            Toast.makeText(this, "Provider not logged in", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        touristRef = FirebaseDatabase.getInstance()
                .getReference("kumbhmela")
                .child("tourist_places");

        btnSubmit.setOnClickListener(v -> saveTouristPlace());

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void initViews() {
        etPlaceName = findViewById(R.id.etPlaceName);
        etLocation = findViewById(R.id.etLocation);
        etCategory = findViewById(R.id.etCategory);
        etEntryFee = findViewById(R.id.etEntryFee);
        etVisitingHours = findViewById(R.id.etVisitingHours);
        etContact = findViewById(R.id.etContact);
        etDescription = findViewById(R.id.etDescription);
        btnSubmit = findViewById(R.id.btnSubmit);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Adding tourist place...");
        progressDialog.setCancelable(false);
    }

    private void saveTouristPlace() {

        String placeName = etPlaceName.getText().toString().trim();
        String location = etLocation.getText().toString().trim();

        if (TextUtils.isEmpty(placeName) || TextUtils.isEmpty(location)) {
            Toast.makeText(this, "Place name & location required", Toast.LENGTH_SHORT).show();
            return;
        }

        progressDialog.show();

        String placeId = touristRef.push().getKey();

        TouristPlace place = new TouristPlace();
        place.setPlaceId(placeId);
        place.setProviderId(providerId);   // ✅ THIS LINE IS CRITICAL
        place.setPlaceName(placeName);
        place.setLocation(location);
        place.setCategory(etCategory.getText().toString().trim());
        place.setEntryFee(etEntryFee.getText().toString().trim());
        place.setVisitingHours(etVisitingHours.getText().toString().trim());
        place.setContact(etContact.getText().toString().trim());
        place.setDescription(etDescription.getText().toString().trim());
        place.setCreatedAt(System.currentTimeMillis());

        touristRef.child(placeId).setValue(place)
                .addOnSuccessListener(unused -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, "Tourist place added successfully", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
                });
    }

}
