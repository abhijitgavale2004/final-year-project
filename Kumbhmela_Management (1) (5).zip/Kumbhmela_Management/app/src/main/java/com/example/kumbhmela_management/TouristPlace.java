package com.example.kumbhmela_management;

public class TouristPlace {

    private String placeId;
    private String providerId;
    private String placeName;
    private String location;
    private String category;
    private String entryFee;
    private String visitingHours;
    private String contact;
    private String description;
    private long createdAt;

    // 🔹 Empty constructor REQUIRED for Firebase
    public TouristPlace() {
    }

    // 🔹 Parameterized constructor
    public TouristPlace(String placeId, String placeName, String location,
                        String category, String entryFee, String visitingHours,
                        String contact, String description, long createdAt) {
        this.placeId = placeId;
        this.placeName = placeName;
        this.location = location;
        this.category = category;
        this.entryFee = entryFee;
        this.visitingHours = visitingHours;
        this.contact = contact;
        this.description = description;
        this.createdAt = createdAt;
    }

    public String getPlaceId() {
        return placeId;
    }

    public void setPlaceId(String placeId) {
        this.placeId = placeId;
    }

    public String getPlaceName() {
        return placeName;
    }

    public void setPlaceName(String placeName) {
        this.placeName = placeName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getEntryFee() {
        return entryFee;
    }

    public void setEntryFee(String entryFee) {
        this.entryFee = entryFee;
    }

    public String getVisitingHours() {
        return visitingHours;
    }

    public void setVisitingHours(String visitingHours) {
        this.visitingHours = visitingHours;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }

    public String getProviderId() {
        return providerId;
    }

    public void setProviderId(String providerId) {
        this.providerId = providerId;
    }
}
