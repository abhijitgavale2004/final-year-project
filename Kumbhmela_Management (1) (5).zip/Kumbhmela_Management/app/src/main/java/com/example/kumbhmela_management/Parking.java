package com.example.kumbhmela_management;
public class Parking {

    private String parkingId;
    private String providerId;
    private String parkingName;
    private String location;
    private String capacity;
    private String price;
    private String contact;
    private String description;
    private long createdAt;

    // REQUIRED empty constructor
    public Parking() {}

    public String getParkingId() { return parkingId; }
    public void setParkingId(String parkingId) { this.parkingId = parkingId; }

    public String getProviderId() { return providerId; }
    public void setProviderId(String providerId) { this.providerId = providerId; }

    public String getParkingName() { return parkingName; }
    public void setParkingName(String parkingName) { this.parkingName = parkingName; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public String getCapacity() { return capacity; }
    public void setCapacity(String capacity) { this.capacity = capacity; }

    public String getPrice() { return price; }
    public void setPrice(String price) { this.price = price; }

    public String getContact() { return contact; }
    public void setContact(String contact) { this.contact = contact; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }
}

