package com.example.kumbhmela_management;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class ParkingAdapter extends RecyclerView.Adapter<ParkingAdapter.VH> {

    private Context context;
    private ArrayList<Parking> list;
    private ArrayList<Parking> listFull;

    public ParkingAdapter(Context context, ArrayList<Parking> list) {
        this.context = context;
        this.list = list;
        this.listFull = new ArrayList<>(list);
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context)
                .inflate(R.layout.item_parking, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Parking p = list.get(position);

        h.tvParkingName.setText(p.getParkingName());
        h.tvLocation.setText(p.getLocation());
        h.tvCapacity.setText(p.getCapacity() + " vehicles");
        h.tvPrice.setText("₹" + p.getPrice() + "/hour");
        h.tvContact.setText(p.getContact());
        h.tvDescription.setText(p.getDescription());

        h.btnDelete.setOnClickListener(v -> showDeleteDialog(p, position));

        // Add animation
        h.cardView.setAlpha(0f);
        h.cardView.animate()
                .alpha(1f)
                .setDuration(300)
                .setStartDelay(position * 50)
                .start();
    }

    private void showDeleteDialog(Parking parking, int position) {
        new AlertDialog.Builder(context)
                .setTitle("Delete Parking")
                .setMessage("Are you sure you want to delete " + parking.getParkingName() + "?")
                .setPositiveButton("Delete", (dialog, which) -> deleteParking(parking, position))
                .setNegativeButton("Cancel", null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    private void deleteParking(Parking parking, int position) {
        DatabaseReference parkingRef = FirebaseDatabase.getInstance()
                .getReference("kumbhmela")
                .child("parkings");

        parkingRef.orderByChild("parkingName")
                .equalTo(parking.getParkingName())
                .get()
                .addOnSuccessListener(snapshot -> {
                    for (DataSnapshot ds : snapshot.getChildren()) {
                        // Check if this is the correct item by matching providerId
                        String providerId = ds.child("providerId").getValue(String.class);
                        if (providerId != null && providerId.equals(parking.getProviderId())) {
                            ds.getRef().removeValue()
                                    .addOnSuccessListener(aVoid -> {
                                        list.remove(position);
                                        notifyItemRemoved(position);
                                        notifyItemRangeChanged(position, list.size());
                                        Toast.makeText(context, "Parking deleted", Toast.LENGTH_SHORT).show();
                                    });

                        }
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(context, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void filter(String query) {
        list.clear();

        if (query.isEmpty()) {
            list.addAll(listFull);
        } else {
            String q = query.toLowerCase();

            for (Parking p : listFull) {

                String name = p.getParkingName() != null ? p.getParkingName().toLowerCase() : "";
                String loc  = p.getLocation() != null ? p.getLocation().toLowerCase() : "";
                String desc = p.getDescription() != null ? p.getDescription().toLowerCase() : "";

                if (name.contains(q) || loc.contains(q) || desc.contains(q)) {
                    list.add(p);
                }
            }
        }
        notifyDataSetChanged();
    }

    public void updateList(ArrayList<Parking> newList) {
        list.clear();
        list.addAll(newList);
        listFull.clear();
        listFull.addAll(newList);
        notifyDataSetChanged();
    }

    static class VH extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView tvParkingName, tvLocation, tvCapacity, tvPrice, tvContact, tvDescription;
        ImageButton btnDelete;

        VH(View v) {
            super(v);
            cardView = v.findViewById(R.id.cardView);
            tvParkingName = v.findViewById(R.id.tvParkingName);
            tvLocation = v.findViewById(R.id.tvLocation);
            tvCapacity = v.findViewById(R.id.tvCapacity);
            tvPrice = v.findViewById(R.id.tvPrice);
            tvContact = v.findViewById(R.id.tvContact);
            tvDescription = v.findViewById(R.id.tvDescription);
            btnDelete = v.findViewById(R.id.btnDelete);
        }
    }
}