package com.example.kumbhmela_management;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class TouristPlaceAdapter extends RecyclerView.Adapter<TouristPlaceAdapter.PlaceViewHolder> {

    private Context context;
    private List<TouristPlace> placeList;
    private List<TouristPlace> placeListFull;

    public TouristPlaceAdapter(Context context, List<TouristPlace> placeList) {
        this.context = context;
        this.placeList = placeList;
        this.placeListFull = new ArrayList<>(placeList);
    }

    @NonNull
    @Override
    public PlaceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_tourist_place, parent, false);
        return new PlaceViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PlaceViewHolder holder, int position) {
        TouristPlace place = placeList.get(position);

        holder.tvPlaceName.setText(place.getPlaceName());
        holder.tvLocation.setText(place.getLocation());
        holder.tvCategory.setText(place.getCategory());

        if (place.getEntryFee() != null && !place.getEntryFee().isEmpty()) {
            holder.tvEntryFee.setText("₹" + place.getEntryFee());
        } else {
            holder.tvEntryFee.setText("Free");
        }

        holder.tvVisitingHours.setText(place.getVisitingHours());
        holder.tvDescription.setText(place.getDescription());

        holder.btnDelete.setOnClickListener(v -> showDeleteDialog(place, position));

        // Add animation
        holder.cardView.setAlpha(0f);
        holder.cardView.animate()
                .alpha(1f)
                .setDuration(300)
                .setStartDelay(position * 50)
                .start();
    }

    private void showDeleteDialog(TouristPlace place, int position) {
        new AlertDialog.Builder(context)
                .setTitle("Delete Place")
                .setMessage("Are you sure you want to delete " + place.getPlaceName() + "?")
                .setPositiveButton("Delete", (dialog, which) -> deletePlace(place, position))
                .setNegativeButton("Cancel", null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    private void deletePlace(TouristPlace place, int position) {
        DatabaseReference touristRef = FirebaseDatabase.getInstance()
                .getReference("kumbhmela")
                .child("tourist_places");

        touristRef.orderByChild("placeName")
                .equalTo(place.getPlaceName())
                .get()
                .addOnSuccessListener(snapshot -> {
                    for (DataSnapshot ds : snapshot.getChildren()) {
                        ds.getRef().removeValue()
                                .addOnSuccessListener(aVoid -> {
                                    Toast.makeText(context, "Place deleted successfully", Toast.LENGTH_SHORT).show();
                                })
                                .addOnFailureListener(e -> {
                                    Toast.makeText(context, "Failed to delete: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                });
                    }
                });
    }

    @Override
    public int getItemCount() {
        return placeList.size();
    }

    public void filter(String query) {
        placeList.clear();
        if (query.isEmpty()) {
            placeList.addAll(placeListFull);
        } else {
            String lowerCaseQuery = query.toLowerCase();
            for (TouristPlace place : placeListFull) {
                if (place.getPlaceName().toLowerCase().contains(lowerCaseQuery) ||
                        place.getLocation().toLowerCase().contains(lowerCaseQuery) ||
                        place.getCategory().toLowerCase().contains(lowerCaseQuery)) {
                    placeList.add(place);
                }
            }
        }
        notifyDataSetChanged();
    }

    public void updateList(List<TouristPlace> newList) {
        placeList.clear();
        placeList.addAll(newList);
        placeListFull.clear();
        placeListFull.addAll(newList);
        notifyDataSetChanged();
    }

    static class PlaceViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView tvPlaceName, tvLocation, tvCategory, tvEntryFee, tvVisitingHours, tvDescription;
        ImageButton btnDelete;

        public PlaceViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.cardView);
            tvPlaceName = itemView.findViewById(R.id.tvPlaceName);
            tvLocation = itemView.findViewById(R.id.tvLocation);
            tvCategory = itemView.findViewById(R.id.tvCategory);
            tvEntryFee = itemView.findViewById(R.id.tvEntryFee);
            tvVisitingHours = itemView.findViewById(R.id.tvVisitingHours);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}