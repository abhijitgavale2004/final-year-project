package com.example.kumbhmela_management;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.*;

import java.util.ArrayList;

public class ViewFoodActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private FoodAdapter adapter;
    private ArrayList<Food> foodList;
    private TextInputEditText searchInput;
    private TextView tvEmpty;

    private DatabaseReference foodRef;
    private String providerId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_food);

        SharedPreferences sp = getSharedPreferences("USER_SESSION", MODE_PRIVATE);
        providerId = sp.getString("PROVIDER_ID", null);

        if (providerId == null) {
            Toast.makeText(this, "Provider not logged in", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        initializeViews();
        setupRecyclerView();
        setupSearch();
        setupToolbar();
        fetchFoodData();
    }

    private void initializeViews() {
        recyclerView = findViewById(R.id.recyclerViewFood);
        progressBar = findViewById(R.id.progressBar);
        searchInput = findViewById(R.id.searchInput);
      //  tvEmpty = findViewById(R.id.tvEmpty);
    }

    private void setupRecyclerView() {
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        foodList = new ArrayList<>();
        adapter = new FoodAdapter(this, foodList);
        recyclerView.setAdapter(adapter);
    }

    private void setupSearch() {
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                adapter.filter(s.toString());
                updateEmptyView();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void setupToolbar() {
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void fetchFoodData() {
        progressBar.setVisibility(View.VISIBLE);

        foodRef = FirebaseDatabase.getInstance()
                .getReference("kumbhmela")
                .child("foods");

        foodRef.orderByChild("providerId")
                .equalTo(providerId)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        foodList.clear();

                        for (DataSnapshot ds : snapshot.getChildren()) {
                            Food food = ds.getValue(Food.class);
                            if (food != null) {
                                foodList.add(food);
                            }
                        }

                        adapter.updateList(foodList);
                        progressBar.setVisibility(View.GONE);
                        updateEmptyView();
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(ViewFoodActivity.this,
                                error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }


    private void updateEmptyView() {
        if (foodList.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
          //  tvEmpty.setVisibility(View.GONE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
          //  tvEmpty.setVisibility(View.GONE);
        }
    }
}