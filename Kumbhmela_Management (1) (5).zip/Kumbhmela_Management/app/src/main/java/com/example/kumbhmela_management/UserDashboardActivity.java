package com.example.kumbhmela_management;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout; // or CardView if using CardView

public class UserDashboardActivity extends AppCompatActivity {

    private LinearLayout cardRooms; // or CardView depending on your XML

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_dashboard);

        // Initialize the Rooms card from layout
        cardRooms = findViewById(R.id.cardRooms);

        // Set click listener
        cardRooms.setOnClickListener(v -> {
            Intent intent = new Intent(this, RoomListActivity.class);
            intent.putExtra("role", "user"); // pass role as "user"
            startActivity(intent);
        });
    }
}
