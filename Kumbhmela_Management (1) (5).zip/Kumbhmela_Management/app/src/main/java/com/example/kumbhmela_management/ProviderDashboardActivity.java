package com.example.kumbhmela_management;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class ProviderDashboardActivity extends AppCompatActivity {

    private ImageButton btnAddParking, btnAddFood, btnAddTourist, btnAddRoom;
    private ImageButton btnViewParking, btnViewFood, btnViewTourist, btnViewRoom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_provider_dashboard);

        // Add buttons
        btnAddParking = findViewById(R.id.btnAddParking);
        btnAddFood = findViewById(R.id.btnAddFood);
        btnAddTourist = findViewById(R.id.btnAddTourist);
        btnAddRoom = findViewById(R.id.btnAddRoom);

        // View buttons
        btnViewParking = findViewById(R.id.btnViewParking);
        btnViewFood = findViewById(R.id.btnViewFood);
        btnViewTourist = findViewById(R.id.btnViewTourist);
        btnViewRoom = findViewById(R.id.btnViewRoom);

        /* ---------------- ADD CLICK LISTENERS ---------------- */

        btnAddParking.setOnClickListener(v ->
                startActivity(new Intent(this, AddParkingActivity.class)));

        btnAddFood.setOnClickListener(v ->
                startActivity(new Intent(this, AddFoodActivity.class)));

        btnAddTourist.setOnClickListener(v ->
                startActivity(new Intent(this, AddTouristPlaceActivity.class)));

        btnAddRoom.setOnClickListener(v ->
                startActivity(new Intent(this, AddRoomActivity.class)));

        /* ---------------- VIEW CLICK LISTENERS ---------------- */

        btnViewParking.setOnClickListener(v ->
                startActivity(new Intent(this, ViewParkingActivity.class)));

        btnViewFood.setOnClickListener(v ->
                startActivity(new Intent(this, ViewFoodActivity.class)));

        btnViewTourist.setOnClickListener(v ->
                startActivity(new Intent(this, TouristPlaceListActivity.class)));
        btnViewRoom.setOnClickListener(v -> {
            Intent intent = new Intent(this, RoomListActivity.class);
            intent.putExtra("role", "provider");
            startActivity(intent);
        });

    }
}
