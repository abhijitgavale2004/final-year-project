package com.example.kumbhmela_management;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class RoomListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RoomAdapter adapter;
    private List<Room> roomList;
    private DatabaseReference roomRef;
    private TextInputEditText etSearch;

    private String role;
    private String providerId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room_list);


        SharedPreferences sp = getSharedPreferences("USER_SESSION", MODE_PRIVATE);
        role = sp.getString("ROLE", "user");        // ✅ FIX
        providerId = sp.getString("PROVIDER_ID", null);


        recyclerView = findViewById(R.id.recyclerView);
        etSearch = findViewById(R.id.etSearch);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        roomList = new ArrayList<>();
        adapter = new RoomAdapter(this, roomList, role);
        recyclerView.setAdapter(adapter);

        roomRef = FirebaseDatabase.getInstance()
                .getReference("kumbhmela")
                .child("rooms");

        fetchRooms();
        setupSearch();
    }

    // ✅ FETCH ROOMS SAME LIKE FOOD
    private void fetchRooms() {

        // Provider → own rooms
        if (role.equals("provider")) {

            roomRef.orderByChild("providerId")
                    .equalTo(providerId)
                    .addValueEventListener(roomListener);

        }
        // User → all rooms
        else {

            roomRef.addValueEventListener(roomListener);
        }
    }

    private final ValueEventListener roomListener = new ValueEventListener() {
        public void onDataChange(@NonNull DataSnapshot snapshot) {

            roomList.clear();

            for (DataSnapshot ds : snapshot.getChildren()) {
                Room room = ds.getValue(Room.class);
                if (room != null) {
                    roomList.add(room);
                }
            }

            adapter.updateFullList();   // ✅ NEW
            adapter.notifyDataSetChanged();
        }


        @Override
        public void onCancelled(@NonNull DatabaseError error) {
            Toast.makeText(RoomListActivity.this,
                    error.getMessage(), Toast.LENGTH_SHORT).show();
        }
    };

    // 🔍 SEARCH
    private void setupSearch() {
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                adapter.filter(s.toString());
            }

            @Override public void afterTextChanged(Editable s) {}
        });
    }
}
