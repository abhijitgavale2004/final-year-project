package com.example.kumbhmela_management;

import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddParkingActivity extends AppCompatActivity {

    private TextInputEditText etParkingName, etLocation, etCapacity,
            etPrice, etContact, etDescription;

    private DatabaseReference parkingRef;
    private ProgressDialog dialog;
    private String providerId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_parking);


        SharedPreferences sp = getSharedPreferences("USER_SESSION", MODE_PRIVATE);
        providerId = sp.getString("USER_ID", null);

        if (providerId == null) {
            Toast.makeText(this, "Provider not logged in", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }


        initViews();
        parkingRef = FirebaseDatabase.getInstance()
                .getReference("kumbhmela").child("parkings");

        findViewById(R.id.btnSubmit).setOnClickListener(v -> saveParking());
        ((MaterialToolbar)findViewById(R.id.toolbar))
                .setNavigationOnClickListener(v -> finish());
    }

    private void initViews() {
        etParkingName = findViewById(R.id.etParkingName);
        etLocation = findViewById(R.id.etLocation);
        etCapacity = findViewById(R.id.etCapacity);
        etPrice = findViewById(R.id.etPrice);
        etContact = findViewById(R.id.etContact);
        etDescription = findViewById(R.id.etDescription);

        dialog = new ProgressDialog(this);
        dialog.setMessage("Adding parking...");
        dialog.setCancelable(false);
    }

    private void saveParking() {
        if (TextUtils.isEmpty(etParkingName.getText()) ||
                TextUtils.isEmpty(etLocation.getText())) {
            Toast.makeText(this, "Required fields missing", Toast.LENGTH_SHORT).show();
            return;
        }

        dialog.show();
        String id = parkingRef.push().getKey();

        Parking parking = new Parking();
        parking.setParkingId(id);
        parking.setProviderId(providerId);
        parking.setParkingName(etParkingName.getText().toString().trim());
        parking.setLocation(etLocation.getText().toString().trim());
        parking.setCapacity(etCapacity.getText().toString().trim());
        parking.setPrice(etPrice.getText().toString().trim());
        parking.setContact(etContact.getText().toString().trim());
        parking.setDescription(etDescription.getText().toString().trim());
        parking.setCreatedAt(System.currentTimeMillis());


        parkingRef.child(id).setValue(parking)
                .addOnSuccessListener(a -> {
                    dialog.dismiss();
                    Toast.makeText(this,"Parking Added",Toast.LENGTH_SHORT).show();
                    finish();
                });
    }
}
