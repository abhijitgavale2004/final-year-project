package com.example.kumbhmela_management;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddFoodActivity extends AppCompatActivity {

    private TextInputEditText etServiceName, etLocation, etFoodType,
            etMealTimes, etPrice, etContact, etDescription;

    private MaterialButton btnSubmit;
    private DatabaseReference foodRef;
    private ProgressDialog progressDialog;

    private String providerId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_food);

        SharedPreferences sp = getSharedPreferences("USER_SESSION", MODE_PRIVATE);
        providerId = sp.getString("PROVIDER_ID", null);


        if (providerId == null) {
            Toast.makeText(this, "Provider not logged in", Toast.LENGTH_LONG).show();
            finish();
            return;
        }


        initViews();
        initFirebase();
        setupToolbar();

        btnSubmit.setOnClickListener(v -> saveFood());
    }

    private void initViews() {
        etServiceName = findViewById(R.id.etServiceName);
        etLocation = findViewById(R.id.etLocation);
        etFoodType = findViewById(R.id.etFoodType);
        etMealTimes = findViewById(R.id.etMealTimes);
        etPrice = findViewById(R.id.etPrice);
        etContact = findViewById(R.id.etContact);
        etDescription = findViewById(R.id.etDescription);
        btnSubmit = findViewById(R.id.btnSubmit);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Adding food service...");
        progressDialog.setCancelable(false);
    }

    private void initFirebase() {
        foodRef = FirebaseDatabase.getInstance()
                .getReference("kumbhmela")
                .child("foods");
    }

    private void setupToolbar() {
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void saveFood() {

        String serviceName = etServiceName.getText().toString().trim();
        String location = etLocation.getText().toString().trim();
        String foodType = etFoodType.getText().toString().trim();
        String mealTimes = etMealTimes.getText().toString().trim();
        String price = etPrice.getText().toString().trim();
        String contact = etContact.getText().toString().trim();
        String description = etDescription.getText().toString().trim();

        if (TextUtils.isEmpty(serviceName) ||
                TextUtils.isEmpty(location) ||
                TextUtils.isEmpty(foodType) ||
                TextUtils.isEmpty(mealTimes) ||
                TextUtils.isEmpty(contact)) {

            Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        progressDialog.show();

        String foodId = foodRef.push().getKey();

        if (foodId == null) {
            progressDialog.dismiss();
            Toast.makeText(this, "Failed to create food ID", Toast.LENGTH_SHORT).show();
            return;
        }
        Food food = new Food();
        food.setFoodId(foodId);
        food.setProviderId(providerId);
        food.setServiceName(serviceName);
        food.setLocation(location);
        food.setFoodType(foodType);
        food.setMealTimes(mealTimes);
        food.setPrice(price);
        food.setContact(contact);
        food.setDescription(description);
        food.setCreatedAt(System.currentTimeMillis());


        foodRef.child(foodId)
                .setValue(food)
                .addOnCompleteListener(task -> {
                    progressDialog.dismiss();
                    if (task.isSuccessful()) {
                        Toast.makeText(this,
                                "Food Service Added Successfully",
                                Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(this,
                                "Error: " + task.getException().getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                });
    }
}
