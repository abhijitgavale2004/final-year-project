package com.example.kumbhmela_management;

import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddRoomActivity extends AppCompatActivity {

    private TextInputEditText etPropertyName, etLocation, etRoomType,
            etAvailableRooms, etPrice, etContact, etAmenities;

    private MaterialButton btnSubmit;
    private ProgressDialog progressDialog;
    private DatabaseReference roomRef;

    private String providerId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_room);

        // Get providerId from intent
        SharedPreferences sp = getSharedPreferences("USER_SESSION", MODE_PRIVATE);
        providerId = sp.getString("PROVIDER_ID", null);


        if (providerId == null) {
            Toast.makeText(this, "Provider not logged in", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }


        initViews();

        roomRef = FirebaseDatabase.getInstance()
                .getReference("kumbhmela")
                .child("rooms");

        btnSubmit.setOnClickListener(v -> saveRoom());

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void initViews() {
        etPropertyName = findViewById(R.id.etPropertyName);
        etLocation = findViewById(R.id.etLocation);
        etRoomType = findViewById(R.id.etRoomType);
        etAvailableRooms = findViewById(R.id.etAvailableRooms);
        etPrice = findViewById(R.id.etPrice);
        etContact = findViewById(R.id.etContact);
        etAmenities = findViewById(R.id.etAmenities);
        btnSubmit = findViewById(R.id.btnSubmit);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Adding room...");
        progressDialog.setCancelable(false);
    }

    private void saveRoom() {

        String propertyName = etPropertyName.getText().toString().trim();
        String location = etLocation.getText().toString().trim();
        String roomType = etRoomType.getText().toString().trim();
        String availableRooms = etAvailableRooms.getText().toString().trim();
        String price = etPrice.getText().toString().trim();
        String contact = etContact.getText().toString().trim();
        String amenities = etAmenities.getText().toString().trim();

        if (TextUtils.isEmpty(propertyName) || TextUtils.isEmpty(location)) {
            Toast.makeText(this, "Property name & location required", Toast.LENGTH_SHORT).show();
            return;
        }

        progressDialog.show();

        String roomId = roomRef.push().getKey();

        Room room = new Room();
        room.setRoomId(roomId);
        room.setProviderId(providerId);
        room.setPropertyName(propertyName);
        room.setLocation(location);
        room.setRoomType(roomType);
        room.setAvailableRooms(availableRooms);
        room.setPrice(price);
        room.setContact(contact);
        room.setAmenities(amenities);
        room.setCreatedAt(System.currentTimeMillis());

        roomRef.child(roomId).setValue(room)
                .addOnSuccessListener(unused -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, "Room added successfully", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
    }
}
