package com.example.kumbhmela_management;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText etEmail, etPassword;
    private MaterialButton btnLogin;
    private RadioGroup rgRole;
    private RadioButton rbUser, rbProvider;
    private TextView tvRegister;

    private DatabaseReference databaseReference;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        rgRole = findViewById(R.id.rgRole);
        rbUser = findViewById(R.id.rbUser);
        rbProvider = findViewById(R.id.rbProvider);
        tvRegister = findViewById(R.id.tvRegister);

        databaseReference = FirebaseDatabase
                .getInstance()
                .getReference("kumbhmela")
                .child("users");

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Logging in...");
        progressDialog.setCancelable(false);

        btnLogin.setOnClickListener(v -> loginUser());

        tvRegister.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
        });
    }

    private void loginUser() {

        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String selectedRole = rbUser.isChecked() ? "user" : "provider";

        if (TextUtils.isEmpty(email)) {
            etEmail.setError("Enter email");
            return;
        }

        if (TextUtils.isEmpty(password)) {
            etPassword.setError("Enter password");
            return;
        }

        progressDialog.show();

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                boolean isLoginSuccess = false;

                for (DataSnapshot userSnap : snapshot.getChildren()) {

                    User user = userSnap.getValue(User.class);

                    if (user == null) continue;

                    if (email.equals(user.getEmail())
                            && password.equals(user.getPassword())
                            && selectedRole.equals(user.getRole())) {

                        isLoginSuccess = true;

                        progressDialog.dismiss();

                        Toast.makeText(LoginActivity.this,
                                "Login Successful",
                                Toast.LENGTH_SHORT).show();
                        getSharedPreferences("USER_SESSION", MODE_PRIVATE)
                                .edit()
                                .putString("USER_ID", user.getUserId())
                                .putString("ROLE", user.getRole())
                                .apply();

                        openDashboard(user.getRole(), user.getUserId());
                        break;
                    }
                }

                if (!isLoginSuccess) {
                    progressDialog.dismiss();
                    Toast.makeText(LoginActivity.this,
                            "Invalid credentials or role",
                            Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressDialog.dismiss();
                Toast.makeText(LoginActivity.this,
                        "DB Error: " + error.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    private void openDashboard(String role, String userId) {

        // ✅ Save session data
        SharedPreferences sp = getSharedPreferences("USER_SESSION", MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();

        editor.putString("USER_ID", userId);   // same for both
        editor.putString("ROLE", role);

        // optional but useful
        if (role.equals("provider")) {
            editor.putString("PROVIDER_ID", userId);
        }

        editor.apply();

        Intent intent;

        if (role.equals("provider")) {
            intent = new Intent(this, ProviderDashboardActivity.class);
        } else {
            intent = new Intent(this, UserDashboardActivity.class);
        }

        startActivity(intent);
        finish();
    }

}
