package com.example.kumbhmela_management;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;
public class RoomAdapter extends RecyclerView.Adapter<RoomAdapter.RoomViewHolder> {

    private Context context;
    private List<Room> roomList;
    private List<Room> roomListFull;
    private String role; // "provider" or "user"

    public RoomAdapter(Context context, List<Room> roomList, String role) {
        this.context = context;
        this.roomList = roomList;
        this.roomListFull = new ArrayList<>(roomList);
        this.role = role;
    }

    @NonNull
    @Override
    public RoomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_room, parent, false);
        return new RoomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RoomViewHolder holder, int position) {

        Room room = roomList.get(position);

        holder.tvPropertyName.setText(room.getPropertyName());
        holder.tvLocation.setText("📍 " + room.getLocation());
        holder.tvRoomType.setText("Room Type: " + room.getRoomType());
        holder.tvAvailableRooms.setText("Available Rooms: " + room.getAvailableRooms());
        holder.tvPrice.setText("₹ " + room.getPrice() + " / Night");
        holder.tvContact.setText("📞 " + room.getContact());
        holder.tvAmenities.setText("Amenities: " + room.getAmenities());

        if (role.equals("provider")) {
            // Show delete button for provider
            holder.ivDelete.setVisibility(View.VISIBLE);
            holder.ivDelete.setOnClickListener(v -> {
                FirebaseDatabase.getInstance()
                        .getReference("kumbhmela")
                        .child("rooms")
                        .child(room.getRoomId())
                        .removeValue();

                Toast.makeText(context, "Room deleted", Toast.LENGTH_SHORT).show();
            });

            // Optional: click on item to edit room
            holder.itemView.setOnClickListener(v -> {
                // Open edit activity
                Intent intent = new Intent(context, AddRoomActivity.class);
                intent.putExtra("roomId", room.getRoomId());
                context.startActivity(intent);
            });

        } else {
            // User flow: hide delete, enable booking
            holder.ivDelete.setVisibility(View.GONE);

            holder.itemView.setOnClickListener(v -> {
                // Open booking flow
                Intent intent = new Intent(context, BookRoomActivity.class);
                intent.putExtra("roomId", room.getRoomId());
                context.startActivity(intent);
            });
        }
    }

    @Override
    public int getItemCount() {
        return roomList.size();
    }

    public void filter(String text) {
        roomList.clear();
        if (text.isEmpty()) {
            roomList.addAll(roomListFull);
        } else {
            text = text.toLowerCase();
            for (Room room : roomListFull) {
                if (room.getPropertyName().toLowerCase().contains(text) ||
                        room.getLocation().toLowerCase().contains(text) ||
                        room.getRoomType().toLowerCase().contains(text)) {
                    roomList.add(room);
                }
            }
        }
        notifyDataSetChanged();
    }
    public void updateFullList() {
        roomListFull.clear();
        roomListFull.addAll(roomList);
    }

    static class RoomViewHolder extends RecyclerView.ViewHolder {
        TextView tvPropertyName, tvLocation, tvRoomType,
                tvAvailableRooms, tvPrice, tvContact, tvAmenities;
        ImageView ivDelete;

        public RoomViewHolder(@NonNull View itemView) {
            super(itemView);
            tvPropertyName = itemView.findViewById(R.id.tvPropertyName);
            tvLocation = itemView.findViewById(R.id.tvLocation);
            tvRoomType = itemView.findViewById(R.id.tvRoomType);
            tvAvailableRooms = itemView.findViewById(R.id.tvAvailableRooms);
            tvPrice = itemView.findViewById(R.id.tvPrice);
            tvContact = itemView.findViewById(R.id.tvContact);
            tvAmenities = itemView.findViewById(R.id.tvAmenities);
            ivDelete = itemView.findViewById(R.id.ivDelete);
        }
    }
}
