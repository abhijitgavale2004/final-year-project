package com.example.kumbhmela_management;
public class Room {

    private String roomId;
    private String providerId;
    private String propertyName;
    private String location;
    private String roomType;
    private String availableRooms;
    private String price;
    private String contact;
    private String amenities;
    private long createdAt;

    public Room() {}

    public String getRoomId() { return roomId; }
    public void setRoomId(String roomId) { this.roomId = roomId; }

    public String getProviderId() { return providerId; }
    public void setProviderId(String providerId) { this.providerId = providerId; }

    public String getPropertyName() { return propertyName; }
    public void setPropertyName(String propertyName) { this.propertyName = propertyName; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public String getRoomType() { return roomType; }
    public void setRoomType(String roomType) { this.roomType = roomType; }

    public String getAvailableRooms() { return availableRooms; }
    public void setAvailableRooms(String availableRooms) { this.availableRooms = availableRooms; }

    public String getPrice() { return price; }
    public void setPrice(String price) { this.price = price; }

    public String getContact() { return contact; }
    public void setContact(String contact) { this.contact = contact; }

    public String getAmenities() { return amenities; }
    public void setAmenities(String amenities) { this.amenities = amenities; }

    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }
}
