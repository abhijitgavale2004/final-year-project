package com.example.kumbhmela_management;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.firebase.database.*;

import java.util.ArrayList;

public class ViewParkingActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private TextView tvEmpty, tvTotalParking;

    private ArrayList<Parking> list;
    private ParkingAdapter adapter;

    private String providerId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_parking);

        SharedPreferences sp = getSharedPreferences("USER_SESSION", MODE_PRIVATE);
        providerId = sp.getString("PROVIDER_ID", null);

        Log.d("DEBUG", "ProviderId = " + providerId);

        if (providerId == null) {
            Toast.makeText(this, "Provider not logged in", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        recyclerView = findViewById(R.id.recyclerView);
        progressBar = findViewById(R.id.progressBar);
        tvEmpty = findViewById(R.id.tvEmpty);
        tvTotalParking = findViewById(R.id.tvTotalParking);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        list = new ArrayList<>();
        adapter = new ParkingAdapter(this, list);
        recyclerView.setAdapter(adapter);

        setupToolbar();
        loadParking();
    }

    private void setupToolbar() {
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void loadParking() {
        progressBar.setVisibility(View.VISIBLE);

        DatabaseReference ref = FirebaseDatabase.getInstance()
                .getReference("kumbhmela")
                .child("parkings");

        ref.orderByChild("providerId")
                .equalTo(providerId)
                .addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        list.clear();

                        for (DataSnapshot ds : snapshot.getChildren()) {
                            Parking parking = ds.getValue(Parking.class);
                            if (parking != null) {
                                list.add(parking);
                            }
                        }

                        adapter.notifyDataSetChanged();
                        progressBar.setVisibility(View.GONE);

                        if (list.isEmpty()) {
                            tvEmpty.setVisibility(View.VISIBLE);
                            recyclerView.setVisibility(View.GONE);
                        } else {
                            tvEmpty.setVisibility(View.GONE);
                            recyclerView.setVisibility(View.VISIBLE);
                            tvTotalParking.setText("Total Parking Areas: " + list.size());
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(ViewParkingActivity.this,
                                error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
