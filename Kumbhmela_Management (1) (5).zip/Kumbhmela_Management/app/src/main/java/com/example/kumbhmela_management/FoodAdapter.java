package com.example.kumbhmela_management;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class FoodAdapter extends RecyclerView.Adapter<FoodAdapter.FoodViewHolder> {

    private Context context;
    private ArrayList<Food> foodList;
    private ArrayList<Food> foodListFull;

    public FoodAdapter(Context context, ArrayList<Food> foodList) {
        this.context = context;
        this.foodList = foodList;
        this.foodListFull = new ArrayList<>(foodList);
    }

    @NonNull
    @Override
    public FoodViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_food, parent, false);
        return new FoodViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FoodViewHolder holder, int position) {
        Food food = foodList.get(position);

        holder.tvServiceName.setText(food.getServiceName());
        holder.tvLocation.setText(food.getLocation());
        holder.tvFoodType.setText(food.getFoodType());
        holder.tvMealTime.setText(food.getMealTimes());

        if (food.getPrice() != null && !food.getPrice().isEmpty()) {
            holder.tvPrice.setText("₹" + food.getPrice());
        } else {
            holder.tvPrice.setText("Price: N/A");
        }

        holder.tvContact.setText(food.getContact());

        holder.btnDelete.setOnClickListener(v -> showDeleteDialog(food, position));

        // Add animation
        holder.cardView.setAlpha(0f);
        holder.cardView.animate()
                .alpha(1f)
                .setDuration(300)
                .setStartDelay(position * 50)
                .start();
    }

    private void showDeleteDialog(Food food, int position) {
        new AlertDialog.Builder(context)
                .setTitle("Delete Food Service")
                .setMessage("Are you sure you want to delete " + food.getServiceName() + "?")
                .setPositiveButton("Delete", (dialog, which) -> deleteFood(food, position))
                .setNegativeButton("Cancel", null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    private void deleteFood(Food food, int position) {
        DatabaseReference foodRef = FirebaseDatabase.getInstance()
                .getReference("kumbhmela")
                .child("foods");

        foodRef.child(food.getFoodId())
                .removeValue()
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(context, "Deleted successfully", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(context, "Delete failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }


    @Override
    public int getItemCount() {
        return foodList.size();
    }
    public void filter(String query) {
        foodList.clear();

        if (query == null || query.trim().isEmpty()) {
            foodList.addAll(foodListFull);
        } else {
            String lowerCaseQuery = query.toLowerCase();

            for (Food food : foodListFull) {

                String name = food.getServiceName() != null ? food.getServiceName().toLowerCase() : "";
                String location = food.getLocation() != null ? food.getLocation().toLowerCase() : "";
                String type = food.getFoodType() != null ? food.getFoodType().toLowerCase() : "";
                String meal = food.getMealTimes() != null ? food.getMealTimes().toLowerCase() : "";

                if (name.contains(lowerCaseQuery)
                        || location.contains(lowerCaseQuery)
                        || type.contains(lowerCaseQuery)
                        || meal.contains(lowerCaseQuery)) {
                    foodList.add(food);
                }
            }
        }
        notifyDataSetChanged();
    }


    public void updateList(ArrayList<Food> newList) {
        foodList.clear();
        foodList.addAll(newList);

        foodListFull.clear();
        foodListFull.addAll(newList);

        notifyDataSetChanged();
    }


    static class FoodViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView tvServiceName, tvLocation, tvFoodType, tvMealTime, tvPrice, tvContact;
        ImageButton btnDelete;

        public FoodViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.cardView);
            tvServiceName = itemView.findViewById(R.id.tvServiceName);
            tvLocation = itemView.findViewById(R.id.tvLocation);
            tvFoodType = itemView.findViewById(R.id.tvFoodType);
            tvMealTime = itemView.findViewById(R.id.tvMealTime);
            tvPrice = itemView.findViewById(R.id.tvPrice);
            tvContact = itemView.findViewById(R.id.tvContact);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}